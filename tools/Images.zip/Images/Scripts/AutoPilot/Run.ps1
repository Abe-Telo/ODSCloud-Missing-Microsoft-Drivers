Write-Host "Setting Execution Policy"
Set-ExecutionPolicy Unrestricted
Write-Host "Execution Policy has been set to"
Get-ExecutionPolicy
Write-Host "Installing Get-WindowsAutoPilotInfo Script"
Install-Script -Name Get-WindowsAutoPilotInfo -force
Write-Host "Getting Autopilot Data"
Get-WindowsAutoPilotInfo -OutputFile .\AutoPilot.csv
Pause