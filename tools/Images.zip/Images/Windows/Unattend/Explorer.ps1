Add-AppxPackage -Register -DisableDevelopmentMode C:\windows\SystemApps\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\appxmanifest.xml
Add-AppxPackage -Register -DisableDevelopmentMode C:\windows\SystemApps\MicrosoftWindows.Client.CBS_cw5n1h2txyewy\AppxManifest.xml
C:\windows\System32\taskkill.exe /F /IM explorer.exe
C:\windows\explorer.exe
